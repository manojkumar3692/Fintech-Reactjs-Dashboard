import React,{PureComponent} from "react";
import LoginStyle from './Login.css';
import RaisedButton from 'material-ui/RaisedButton';
import { Grid, Row, Col } from 'react-flexbox-grid';
import Paper from 'material-ui/Paper';
import TextFiled from "../../common/TextField/TextField";
import Button from "../../common/Button/Button";
class Login extends PureComponent {
	constructor(props) {
		super(props)
	}
	onSuccessLogin() {
		this.props.history.push('/appDashboard/explore');
	}
	render() {
		return (
			<div className="login">

				<Row middle="xs" className="loginOuter">
					<Col xs={12}>
						<Paper className="loginContainer" zDepth={5}>
							<h1>Account Login</h1>
							<TextFiled placeholderText="Username" label="Username"/>
							<TextFiled placeholderText="Password" label="Password"/>
							<Button validate={this.onSuccessLogin.bind(this)} buttonLabel="Submit"/>
						</Paper>
					</Col>
				</Row>

			</div>
		)
	}
}

export default Login;
