import React,{PureComponent} from  'react';
import { Grid, Row, Col } from 'react-flexbox-grid';
import "./Header.scss";
export default class Header extends PureComponent {
	constructor(props) {
		super(props)
	}

	render() {
		return (
			<div className="header">
				<Row>
					<Col xs={8}>
						<h1>Niyo Solution</h1>
					</Col>
					<Col xs={4}>
						<h2>Logout</h2>
					</Col>
				</Row>
			</div>
		)
	}
}